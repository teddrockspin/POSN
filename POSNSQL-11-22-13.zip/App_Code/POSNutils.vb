﻿Public Class POSNutils
function GetSupply() as string

end function 

End Class
