﻿Partial Class dsLookup
End Class
