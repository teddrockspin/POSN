﻿Partial Class dsAccessCodes
End Class
