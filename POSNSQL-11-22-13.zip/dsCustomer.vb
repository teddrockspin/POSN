﻿

Partial Public Class dsCustomer
End Class


Partial Public Class dsCustomer
End Class
