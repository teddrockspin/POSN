﻿Public Partial Class dev
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '  PdfWebControl1.CreateDocument("filename", System.IO.File.ReadAllBytes(Server.MapPath("portal.pdf")))
    End Sub

End Class